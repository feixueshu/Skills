#!/usr/bin/env python3
"""List/extract final-video QA points; does not listen, OCR or certify semantics."""
import argparse
from fractions import Fraction
import json
import math
from pathlib import Path
import subprocess
import sys
from check_demo_plan import number, probe, validate


def review_points(plan, extra=()):
    points = []
    duration, fps = plan['duration'], plan['canvas']['fps']
    margin = 1 / fps
    def add(t, step, phase, caption=None):
        safe = max(0, min(t, duration-margin))
        frame = max(0, math.floor((safe+1e-9)*fps))
        item = {'time': frame/fps, 'frame_index': frame, 'step': step, 'phase': phase}
        if caption is not None:
            item['caption'] = caption
        points.append(item)
    def triple(a, b, step, prefix, caption=None):
        delta = min(.24, (b-a)/4)
        for t, phase in [(a+delta, prefix+'_start'), ((a+b)/2, prefix+'_mid'), (b-delta, prefix+'_end')]:
            add(t, step, phase, caption)
    for step in plan['steps']:
        sid, start, end, hold = step['id'], step['start'], step['end'], step['hold_start']
        add(start, sid, 'scene_start')
        if hold > start:
            add((start+hold)/2, sid, 'action_mid')
        triple(hold, end, sid, 'hold')
        for t in (start, hold, end):
            add(t-margin, sid, 'transition_before')
            add(t+margin, sid, 'transition_after')
        highlights = step.get('highlights', [step['highlight']] if step.get('highlight') is not None else [])
        for h in highlights:
            triple(h['start'], h['end'], sid, 'highlight')
        for index, cap in enumerate(step.get('captions', [])):
            cid = cap.get('id', sid+'-caption-'+str(index+1))
            triple(cap['start'], cap['end'], sid, 'caption', cid)
            ref = cap.get('reading_reference')
            if ref:
                triple(ref['start'], ref['end'], sid, 'reading', cid)
                add(min(cap['end']-margin, ref['end']+margin), sid, 'after_reference_reading', cid)
            if number(cap.get('reading_end')):
                add(min(cap['end']-margin, cap['reading_end']+margin), sid, 'after_reading_budget', cid)
    for index, motion in enumerate(plan.get('motions', [])):
        label = 'motion-'+str(index+1)
        add((motion['start']+motion['end'])/2, label, 'motion_mid')
        for t in (motion['start'], motion['end']):
            add(t-margin, label, 'transition_before')
            add(t+margin, label, 'transition_after')
    for t in extra:
        if not number(t) or not 0 <= t < duration:
            raise ValueError('extra times must fall inside final duration')
        add(t, 'user', 'reported_time')
    return sorted(points, key=lambda p: (p['frame_index'], p['step'], p['phase']))


def verify_final_streams(plan, info):
    actual = float(info['format']['duration'])
    streams = info.get('streams', [])
    video = [s for s in streams if s.get('codec_type') == 'video']
    if not video or abs(actual-plan['duration']) > .2:
        raise ValueError('Final video missing video stream or duration differs >0.2s')
    canvas = plan['canvas']
    if (video[0]['width'], video[0]['height']) != (canvas['width'], canvas['height']):
        raise ValueError('Final video dimensions differ from plan')
    rate = video[0].get('r_frame_rate')
    if rate and abs(float(Fraction(rate))-canvas['fps']) > .001:
        raise ValueError('Final video frame rate differs from plan')
    if 'total_frames' in plan and int(video[0].get('nb_frames', -1)) != plan['total_frames']:
        raise ValueError('Final video frame count differs from plan')
    audio = [s for s in streams if s.get('codec_type') == 'audio']
    if plan.get('audio_mode') == 'silent' and audio:
        raise ValueError('Silent delivery unexpectedly contains an audio stream')
    if plan.get('audio_mode') == 'narrated' and not audio:
        raise ValueError('Narrated delivery has no audio stream')
    return {'duration': actual, 'video_streams': len(video), 'audio_streams': len(audio)}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('plan', type=Path)
    ap.add_argument('--root', type=Path)
    ap.add_argument('--video', type=Path)
    ap.add_argument('--output', type=Path)
    ap.add_argument('--extra-at', default='', help='comma-separated final-video seconds')
    args = ap.parse_args()
    try:
        plan = json.loads(args.plan.read_text(encoding='utf-8'))
        errors, _ = validate(plan, args.root or args.plan.parent)
        if errors:
            raise ValueError('; '.join(errors))
        points = review_points(plan, [float(v) for v in args.extra_at.split(',') if v.strip()])
        if bool(args.video) != bool(args.output):
            raise ValueError('--video and --output must be supplied together')
        report = {'status': 'review-points-only', 'points': points, 'human_review_required': True}
        if args.video:
            video = args.video.resolve(strict=True)
            report['streams'] = verify_final_streams(plan, probe(video))
            args.output.mkdir(parents=True, exist_ok=False)
            files = {}
            for item in points:
                frame, t = item['frame_index'], item['time']
                if frame not in files:
                    name = 'frame-%04d-%010.6fs.png' % (len(files)+1, t)
                    dest = args.output/name
                    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-n', '-ss', '%.9f' % t,
                                    '-i', str(video), '-frames:v', '1', str(dest)],
                                   capture_output=True, check=True, timeout=30)
                    if not dest.is_file() or dest.stat().st_size == 0:
                        raise ValueError('No decoded review frame at '+str(t))
                    files[frame] = name
                item['file'] = files[frame]
            report['status'] = 'extracted-not-reviewed'
            (args.output/'manifest.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, TypeError, KeyError, subprocess.SubprocessError) as exc:
        print(json.dumps({'status': 'failed', 'error': str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
