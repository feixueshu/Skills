#!/usr/bin/env python3
"""Read-only local demo checks. Does not certify semantics, voice quality or execution."""
import argparse
import json
import math
from pathlib import Path
import subprocess
import sys

REFERENCE_METHODS = {'local_tts', 'online_tts', 'presenter_recording', 'user_reported', 'manual_estimate', 'illustrative'}


def number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def local_asset(root, value):
    if not isinstance(value, str) or not value or '\\' in value or ':' in value:
        raise ValueError('asset must be a local relative path')
    p = Path(value)
    if p.is_absolute() or '..' in p.parts:
        raise ValueError('absolute and parent paths are not allowed')
    resolved = (root / p).resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError('asset escapes root, including via symlink')
    return resolved


def probe(path):
    result = subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)],
                            capture_output=True, text=True, timeout=30, check=True)
    return json.loads(result.stdout)


def intersects(a, b):
    return a[0] < b[0]+b[2] and b[0] < a[0]+a[2] and a[1] < b[1]+b[3] and b[1] < a[1]+a[3]


def validate(plan, root, use_probe=False):
    errors, warnings, protected = [], [], []
    def require(ok, message):
        if not ok:
            errors.append(message)
        return ok
    def rect(v, w, h, label):
        return require(isinstance(v, list) and len(v) == 4 and all(number(x) for x in v)
                       and v[0] >= 0 and v[1] >= 0 and v[2] > 0 and v[3] > 0
                       and v[0]+v[2] <= w and v[1]+v[3] <= h, label+' invalid/outside canvas')
    def interval(obj, lo, hi, label):
        if not isinstance(obj, dict):
            require(False, label+' must be an object')
            return False
        a, b = obj.get('start'), obj.get('end')
        return require(number(a) and number(b) and lo <= a < b <= hi, label+' invalid timing')
    def asset(value, label):
        try:
            path = local_asset(root, value)
            if use_probe and not path.is_file():
                raise ValueError('missing file')
            return path
        except (ValueError, OSError) as exc:
            require(False, label+': '+str(exc))
            return None
    def audio_duration(obj, label):
        require(isinstance(obj.get('spoken_text'), str) and bool(obj['spoken_text'].strip()), label+' spoken text missing')
        path = asset(obj.get('path'), label)
        if use_probe and path and path.is_file():
            try:
                info = probe(path)
                require(any(x.get('codec_type') == 'audio' for x in info['streams']), label+' has no audio')
                actual = float(info['format']['duration'])
                require(abs(actual-(obj['end']-obj['start'])) <= .15,
                        label+' duration differs from actual audio (>0.15s); use final audio')
            except (OSError, subprocess.SubprocessError, ValueError, KeyError, StopIteration):
                require(False, label+' ffprobe failed')
    if not require(isinstance(plan, dict), 'plan must be an object'):
        return errors, warnings
    require(plan.get('schema_version') == 1, 'schema_version must be 1')
    require(plan.get('language') == 'ja-JP', 'language must be ja-JP')
    mode = plan.get('audio_mode', 'narrated')  # Preserve the original narrated schema.
    require(mode in ('silent', 'narrated'), 'audio_mode must be silent or narrated')
    timing_mode = plan.get('timing_mode', 'standard')
    require(timing_mode in ('standard', 'read_along'), 'unknown timing_mode')
    canvas = plan.get('canvas', {})
    if not require(isinstance(canvas, dict), 'canvas must be an object'):
        return errors, warnings
    w, h, fps = canvas.get('width'), canvas.get('height'), canvas.get('fps')
    if not require(all(number(v) and v > 0 for v in (w, h, fps)), 'canvas dimensions/fps must be positive finite numbers'):
        return errors, warnings
    require(all(isinstance(v, int) and not isinstance(v, bool) and v % 2 == 0 for v in (w, h)), 'canvas dimensions must be even integers')
    require(fps <= 120, 'fps exceeds 120')
    zone = canvas.get('caption_zone')
    zone_ok = rect(zone, w, h, 'caption_zone')
    duration = plan.get('duration')
    if not require(number(duration) and duration > 0, 'duration must be positive finite'):
        return errors, warnings
    sources = plan.get('sources')
    if not require(isinstance(sources, dict) and bool(sources), 'sources must be a nonempty object'):
        return errors, warnings
    source_info = {}
    for key, src in sources.items():
        if not require(isinstance(src, dict), 'source '+key+' must be an object'):
            continue
        path = asset(src.get('path'), 'source '+key)
        dims = (src.get('width'), src.get('height'))
        require(all(number(v) and v > 0 for v in dims), 'source '+key+' invalid dimensions')
        if src.get('provenance') != 'reviewed-real-ui':
            warnings.append('source '+key+': authentic UI provenance requires human review')
        if use_probe and path and path.is_file():
            try:
                info = probe(path)
                video = next(s for s in info['streams'] if s.get('codec_type') == 'video')
                require((video.get('width'), video.get('height')) == dims, 'source '+key+' actual dimensions differ')
                source_info[key] = float(info['format']['duration'])
            except (OSError, subprocess.SubprocessError, ValueError, KeyError, StopIteration):
                require(False, 'source '+key+' ffprobe failed/no duration or video')
    steps = plan.get('steps')
    if not require(isinstance(steps, list) and bool(steps), 'steps must be a nonempty array'):
        return errors, warnings
    ids, cap_ids, previous_end = set(), set(), 0
    for i, step in enumerate(steps):
        tag = 'step '+str(i+1)
        if not require(isinstance(step, dict), tag+' must be an object'):
            continue
        sid = step.get('id')
        if require(isinstance(sid, str) and bool(sid), tag+' missing string id'):
            require(sid not in ids, tag+' duplicate id')
            ids.add(sid)
        if not interval(step, 0, duration, tag):
            continue
        start, end = step['start'], step['end']
        require(start >= previous_end, tag+' overlaps/out of order')
        if start > previous_end+.001:
            warnings.append(tag+': uncovered gap before scene; verify intended transition')
        previous_end = end
        hold = step.get('hold_start')
        if not require(number(hold) and start <= hold < end, tag+' invalid hold_start'):
            continue
        key = step.get('source')
        src = sources.get(key) if isinstance(key, str) else None
        require(isinstance(src, dict), tag+' unknown source')
        source_time = step.get('source_hold_time')
        if require(number(source_time) and source_time >= 0, tag+' invalid source_hold_time') and key in source_info:
            require(source_time < source_info[key], tag+' hold frame outside source duration')
        if 'crop' in step and isinstance(src, dict) and all(number(src.get(k)) for k in ('width', 'height')):
            rect(step['crop'], src['width'], src['height'], tag+' crop (source coordinates)')
        narration = step.get('narration')
        if mode == 'narrated':
            if interval(narration, hold, end, tag+' narration'):
                audio_duration(narration, tag+' narration')
                protected.append((narration, tag+' narration'))
        elif narration is not None:
            require(False, tag+': silent plan must not declare delivery narration; use caption reading_reference')
        if 'highlight' in step and 'highlights' in step:
            require(False, tag+': use highlight or highlights, not both')
        highlights = step.get('highlights', [step['highlight']] if step.get('highlight') is not None else [])
        if require(isinstance(highlights, list), tag+' highlights must be an array'):
            for index, hi in enumerate(highlights):
                label = tag+' highlight '+str(index+1)
                if not interval(hi, hold, end, label):
                    continue
                protected.append((hi, label))
                a_ok = rect(hi.get('rect'), w, h, label+' rect')
                require(isinstance(hi.get('target_anchor'), str) and bool(hi['target_anchor'].strip()), label+' target_anchor missing')
                if a_ok and zone_ok:
                    require(not intersects(hi['rect'], zone), label+' overlaps caption zone')
                if 'label_rect' in hi:
                    b_ok = rect(hi['label_rect'], w, h, label+' label rect')
                    require(isinstance(hi.get('label_ja'), str) and bool(hi['label_ja'].strip()), label+' label_ja missing')
                    if a_ok and b_ok:
                        require(not intersects(hi['rect'], hi['label_rect']), label+' label obscures target')
                    if b_ok and zone_ok:
                        require(not intersects(hi['label_rect'], zone), label+' label overlaps caption zone')
        caps = step.get('captions', [])
        if require(isinstance(caps, list), tag+' captions must be array'):
            cap_end = hold
            for index, cap in enumerate(caps):
                label = tag+' caption '+str(index+1)
                if not interval(cap, hold, end, label):
                    continue
                require(cap['start'] >= cap_end, label+' overlaps/out of order')
                cap_end = cap['end']
                protected.append((cap, label))
                require(isinstance(cap.get('text'), str) and bool(cap['text'].strip()), label+' empty text')
                if 'id' in cap:
                    require(isinstance(cap['id'], str) and bool(cap['id']) and cap['id'] not in cap_ids, label+' invalid/duplicate id')
                    if isinstance(cap['id'], str):
                        cap_ids.add(cap['id'])
                ref = cap.get('reading_reference')
                if timing_mode == 'read_along':
                    require(isinstance(ref, dict), label+' requires a reading_reference')
                if ref is not None and interval(ref, cap['start'], cap['end'], label+' reading_reference'):
                    require(ref.get('method') in REFERENCE_METHODS, label+' unknown reading method')
                    require(isinstance(ref.get('spoken_text'), str) and bool(ref['spoken_text'].strip()), label+' spoken_text missing')
                    if 'path' in ref:
                        audio_duration(ref, label+' reading reference')
                        if not use_probe:
                            warnings.append(label+': reading audio duration not probed')
                    elif ref.get('method') != 'user_reported':
                        warnings.append(label+': reading reference is not tool-verified audio')
                    if ref.get('method') in ('manual_estimate', 'illustrative'):
                        warnings.append(label+': estimated/example timing is not actual reading evidence')
                    if 'reading_end' in cap:
                        require(number(cap['reading_end']) and ref['end'] <= cap['reading_end'] <= cap['end'], label+' reading budget invalid')
                    protected.append((ref, label+' reading reference'))
    if previous_end < duration-.001:
        warnings.append('Timeline ends before declared duration; verify intended tail')
    motions = plan.get('motions', [])
    if require(isinstance(motions, list), 'motions must be an array'):
        for index, motion in enumerate(motions):
            label = 'motion '+str(index+1)
            if interval(motion, 0, duration, label):
                for obj, tag in protected:
                    require(not (obj['start'] < motion['end'] and obj['end'] > motion['start']), tag+' overlaps '+label)
    if not use_probe:
        warnings.append('Structure only: media existence, duration and streams not probed')
    return errors, warnings


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('plan', type=Path)
    ap.add_argument('--root', type=Path)
    ap.add_argument('--probe', action='store_true')
    args = ap.parse_args()
    try:
        plan = json.loads(args.plan.read_text(encoding='utf-8'))
        errors, warnings = validate(plan, args.root or args.plan.parent, args.probe)
    except (ValueError, OSError, TypeError) as exc:
        errors, warnings = ['Cannot validate plan: '+str(exc)], []
    print(json.dumps({'ok': not errors, 'errors': errors, 'warnings': warnings,
        'limitations': 'Does not verify UI semantics, Japanese quality, authentic execution, human listening or final rendering.'}, ensure_ascii=False, indent=2))
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
