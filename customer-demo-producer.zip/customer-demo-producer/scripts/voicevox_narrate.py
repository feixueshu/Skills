#!/usr/bin/env python3
"""Local-only VOICEVOX/Nemo audition or sentence synthesis; stdlib, no installer.

Reads a JSON plan, queries the running engine's actual speakers, saves one WAV
per sentence, and (narration mode only) builds an unnormalized PCM timeline if
all sentences fit their approved caption/stable-screen windows. Does not mux,
change picture timing, normalize each sentence, or claim human listening.
"""
import argparse
import json
import math
from pathlib import Path
import re
import urllib.parse
import urllib.request
import wave


def number(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f'{name}: expected a finite number')
    if not math.isfinite(value) or value < minimum:
        raise ValueError(f'{name}: invalid number')
    return value


def local_endpoint(value):
    p = urllib.parse.urlsplit(value)
    # Accessing .port also rejects placeholders, nonnumeric and out-of-range ports.
    p.port
    if (p.scheme != 'http' or p.hostname not in ('127.0.0.1', 'localhost', '::1')
            or p.username or p.password or p.query or p.fragment or p.path not in ('', '/')):
        raise ValueError('Use a local HTTP engine origin only; remote providers are not supported')
    return value.rstrip('/')


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('Local engine redirect rejected')


def request(endpoint, path, params=None, body=None):
    url = local_endpoint(endpoint) + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, data=body,
                                 headers={'Content-Type': 'application/json'})
    # No proxy or external text delivery for this local-only helper.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    with opener.open(req, timeout=180) as response:
        return response.read()


def validate_plan(plan):
    local_endpoint(plan['endpoint'])
    mode = plan.get('mode')
    if mode not in ('audition', 'narration'):
        raise ValueError('mode must be audition or narration')
    if plan.get('terms_reviewed') is not True or not plan.get('credit') or not plan.get('terms_url'):
        raise ValueError('Record reviewed voice-library terms, terms_url, and required credit')
    if mode == 'narration' and plan.get('voice_approved') is not True:
        raise ValueError('Obtain voice approval before full narration')
    if not plan.get('speaker_name') or not plan.get('style_name'):
        raise ValueError('Select speaker_name and style_name from the actual /speakers response')
    cues = plan.get('cues', [])
    if not cues:
        raise ValueError('No cues')
    settings = plan.get('settings', {})
    allowed = {'speedScale', 'intonationScale', 'pitchScale', 'prePhonemeLength', 'postPhonemeLength'}
    if set(settings) - allowed:
        raise ValueError('Unsupported voice setting')
    for k, v in settings.items():
        number(v, k, -1 if k == 'pitchScale' else 0)
    if settings.get('speedScale', 1) <= 0:
        raise ValueError('speedScale must be positive')
    duration = number(plan['duration'], 'duration', .001) if mode == 'narration' else None
    tail = number(plan.get('minimum_tail', .25), 'minimum_tail')
    ids = set(); previous_end = 0
    for c in cues:
        cid = c['id']
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', cid) or cid in ids:
            raise ValueError('Cue IDs must be unique filename-safe identifiers')
        ids.add(cid)
        if not isinstance(c.get('display_text'), str) or not c['display_text'].strip():
            raise ValueError(f'{cid}: missing display_text')
        if not isinstance(c.get('spoken_text'), str) or not c['spoken_text'].strip():
            raise ValueError(f'{cid}: missing spoken_text')
        if mode == 'narration':
            for key in ('start', 'end', 'stable_start', 'stable_end'):
                number(c[key], key)
            if not (previous_end <= c['start'] < c['end'] <= duration
                    and c['stable_start'] <= c['start'] < c['end'] <= c['stable_end'] <= duration):
                raise ValueError(f'{cid}: overlapping/out-of-range caption or stable-screen window')
            if c['end']-c['start'] <= tail:
                raise ValueError(f'{cid}: caption window too short')
            previous_end = c['end']
    return mode


def resolve_speaker(speakers, name, style):
    matches = [s['id'] for v in speakers if v['name'] == name
               for s in v['styles'] if s['name'] == style]
    if len(matches) != 1:
        raise ValueError('Speaker/style unavailable or ambiguous; inspect current engine voices')
    return matches[0]


def pcm(path):
    with wave.open(str(path), 'rb') as f:
        if f.getcomptype() != 'NONE' or f.getnchannels() != 1 or f.getsampwidth() != 2:
            raise ValueError('Expected mono 16-bit PCM WAV; refusing implicit conversion')
        rate = f.getframerate(); raw = f.readframes(f.getnframes())
    if not raw or not any(raw):
        raise ValueError('Empty or silent synthesized audio')
    return rate, raw


def build_timeline(rows, duration, output, minimum_tail=.25):
    """Fail without creating timeline when any cue overruns, overlaps or changes format."""
    chunks = []; rate = None; previous_end = 0
    for c in rows:
        current_rate, raw = pcm(c['audio'])
        if rate is None:
            rate = current_rate
        if current_rate != rate:
            raise ValueError('Mixed sample rates; convert explicitly before mixing')
        seconds = len(raw) / (2 * rate)
        if c['end'] - c['start'] - seconds < minimum_tail - 1e-7:
            raise ValueError(f"{c['id']}: voice overrun; extend affected hold or revise voice, do not truncate")
        start = round(c['start'] * rate); stop = start + len(raw)//2
        if start < previous_end or stop > round(duration * rate):
            raise ValueError('PCM placement would overlap or exceed the full timeline')
        previous_end = stop; chunks.append((start, raw))
    out = Path(output)
    if out.exists():
        raise FileExistsError(out)
    with wave.open(str(out), 'wb') as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(rate)
        cursor = 0
        for start, raw in chunks:
            f.writeframesraw(b'\0\0' * (start-cursor)); f.writeframesraw(raw)
            cursor = start+len(raw)//2
        f.writeframesraw(b'\0\0' * (round(duration * rate)-cursor))


def synthesize(plan, output):
    mode = validate_plan(plan)
    output = Path(output)
    if output.exists():
        raise FileExistsError('Use a new output directory; previous outputs are never overwritten')
    voices = json.loads(request(plan['endpoint'], '/speakers'))
    speaker = resolve_speaker(voices, plan['speaker_name'], plan['style_name'])
    version = json.loads(request(plan['endpoint'], '/version'))
    output.mkdir(parents=True)
    (output/'音声クレジット.txt').write_text(plan['credit']+'\n'+plan['terms_url']+'\n')
    rows = []
    for cue in plan['cues']:
        query = json.loads(request(plan['endpoint'], '/audio_query',
                           {'text': cue['spoken_text'], 'speaker': speaker}, b''))
        query.update(plan.get('settings', {}))
        # Request one consistent PCM format; do not change timing settings here.
        query.update(outputSamplingRate=24000, outputStereo=False)
        raw = request(plan['endpoint'], '/synthesis', {'speaker': speaker},
                      json.dumps(query, ensure_ascii=False).encode('utf-8'))
        audio = output / (cue['id']+'.wav'); audio.write_bytes(raw)
        rate, samples = pcm(audio)
        row = dict(cue, audio=str(audio.resolve()), measured_seconds=len(samples)/(2*rate),
                   kana=query.get('kana'), query=query)
        if mode == 'narration':
            row['audio_end'] = cue['start'] + row['measured_seconds']
            row['caption_tail'] = cue['end'] - row['audio_end']
        rows.append(row)
        (output/(cue['id']+'.json')).write_text(json.dumps(row, ensure_ascii=False, indent=2))
    report = {'mode': mode, 'engine_version': version, 'speaker_name': plan['speaker_name'],
              'style_name': plan['style_name'], 'resolved_speaker_id': speaker,
              'voice_library_version': next(v.get('version') for v in voices if v['name'] == plan['speaker_name']),
              'voice_approved': plan.get('voice_approved', False), 'credit': plan['credit'],
              'terms_url': plan['terms_url'], 'terms_reviewed': True, 'cues': rows,
              'human_listening_verified': False, 'timeline_ready': False}
    report_path = output/'manifest.json'
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    if mode == 'narration':
        # The report and individual WAVs remain available if fit validation fails.
        timeline = output/'timeline-raw.wav'
        build_timeline(rows, plan['duration'], timeline, plan.get('minimum_tail', .25))
        report.update(timeline_ready=True, timeline=str(timeline.resolve()), duration=plan['duration'])
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('plan', nargs='?', type=Path)
    p.add_argument('--output', type=Path)
    p.add_argument('--list-voices', metavar='LOCAL_ENGINE_ORIGIN')
    args = p.parse_args()
    if args.list_voices:
        print(json.dumps(json.loads(request(args.list_voices, '/speakers')), ensure_ascii=False, indent=2))
        return
    if not args.plan or not args.output:
        p.error('Provide a JSON plan and a new --output directory, or --list-voices')
    report = synthesize(json.loads(args.plan.read_text()), args.output)
    print(json.dumps({'sentences': len(report['cues']), 'timeline_ready': report['timeline_ready'],
                      'manifest': str((args.output/'manifest.json').resolve())}, ensure_ascii=False))


if __name__ == '__main__':
    main()
