/** Encode continuous, authorized screenshots. This module never selects or controls UI. */
import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { once } from 'node:events';
import { performance } from 'node:perf_hooks';
import path from 'node:path';

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function deadline(promise, ms) {
  let timer;
  try { return await Promise.race([promise, new Promise(resolve => { timer = setTimeout(() => resolve(null), ms); })]); }
  finally { clearTimeout(timer); }
}
function boundedNumber(value, name, min, max, integer = false) {
  if (!Number.isFinite(value) || value < min || value > max || (integer && !Number.isInteger(value))) {
    throw new Error(`Invalid ${name}`);
  }
  return value;
}
export function inspectImage(value) {
  if (!(value instanceof Uint8Array)) throw new Error('Capture must return PNG/JPEG bytes');
  const b = Buffer.from(value);
  if (b.length < 24 || b.length > 16 * 1024 * 1024) throw new Error('Invalid image byte length');
  if (b.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
    const width = b.readUInt32BE(16), height = b.readUInt32BE(20);
    if (!width || !height || width > 16384 || height > 16384) throw new Error('Invalid PNG dimensions');
    return { codec: 'png', width, height, bytes: b };
  }
  if (b[0] === 0xff && b[1] === 0xd8) {
    let p = 2;
    while (p + 4 <= b.length) {
      if (b[p++] !== 0xff) continue;
      while (p < b.length && b[p] === 0xff) p++;
      const marker = b[p++];
      if (marker === 0xd9 || marker === 0xda) break;
      if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
      if (p + 2 > b.length) break;
      const len = b.readUInt16BE(p);
      if (len < 2 || p + len > b.length) break;
      if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker)) {
        if (len < 8) break;
        const height = b.readUInt16BE(p + 3), width = b.readUInt16BE(p + 5);
        if (!width || !height || width > 16384 || height > 16384) break;
        return { codec: 'mjpeg', width, height, bytes: b };
      }
      p += len;
    }
  }
  throw new Error('Only valid PNG or JPEG screenshots are supported');
}
async function captureWithTimeout(fn, ms) {
  let timer;
  try {
    return await Promise.race([
      Promise.resolve().then(fn),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('CAPTURE_TIMEOUT')), ms); })
    ]);
  } finally { clearTimeout(timer); }
}
export async function startLiveTabRecorder({
  captureFrame, output, ffmpeg = 'ffmpeg', width = 1920, height = 1080,
  fps = 30, minIntervalMs = 80, maxSeconds = 120, frameTimeoutMs = 15000,
  encoderCloseTimeoutMs = 15000
} = {}) {
  if (typeof captureFrame !== 'function' || typeof output !== 'string' || !output.trim()) {
    throw new Error('Provide an authorized captureFrame callback and a new local output path');
  }
  boundedNumber(width, 'width', 2, 7680, true); boundedNumber(height, 'height', 2, 7680, true);
  if (width % 2 || height % 2) throw new Error('Output dimensions must be even for yuv420p');
  boundedNumber(fps, 'fps', 1, 120, true); boundedNumber(minIntervalMs, 'minIntervalMs', 20, 5000);
  boundedNumber(maxSeconds, 'maxSeconds', .1, 3600); boundedNumber(frameTimeoutMs, 'frameTimeoutMs', 50, 120000);
  boundedNumber(encoderCloseTimeoutMs, 'encoderCloseTimeoutMs', 100, 120000);
  if (path.extname(output).toLowerCase() !== '.mp4') throw new Error('Output must be a new .mp4 file');
  const file = path.resolve(output), metaPath = file + '.capture.json', logPath = file + '.ffmpeg.log';
  await fs.mkdir(path.dirname(file), { recursive: true });
  for (const p of [file, metaPath, logPath]) {
    try { await fs.lstat(p); throw new Error('Refusing to overwrite an existing capture artifact'); }
    catch (e) { if (e.code !== 'ENOENT') throw e; }
  }
  const lockPath = file + '.capture.lock';
  const lock = await fs.open(lockPath, 'wx');
  let log, proc;
  async function releaseLock() { await lock.close(); await fs.unlink(lockPath).catch(() => {}); }
  let first;
  try {
    first = inspectImage(await captureWithTimeout(captureFrame, frameTimeoutMs));
    log = createWriteStream(logPath, { flags: 'wx' });
    await once(log, 'open');
  } catch (_) {
    if (log) log.end();
    await releaseLock();
    throw new Error('Could not obtain a valid first frame or open capture output');
  }
  const started = performance.now();
  const state = {
    running: true, status: 'recording', frameTimes: [], frames: 0, events: [], errorCode: null,
    stopReason: null, source: { codec: first.codec, width: first.width, height: first.height },
    canvas: { width, height, fps }, outputBasename: path.basename(file)
  };
  const args = ['-hide_banner', '-n', '-probesize', '32', '-analyzeduration', '0',
    '-f', 'image2pipe', '-vcodec', first.codec,
    '-framerate', String(fps), '-i', 'pipe:0', '-an', '-vf',
    `setpts=PTS-STARTPTS,scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:color=0x14222D,fps=${fps}`,
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p',
    '-movflags', '+faststart', file];
  proc = spawn(ffmpeg, args, { stdio: ['pipe', 'ignore', 'pipe'] });
  let spawnError = false;
  const closed = new Promise(resolve => {
    proc.once('error', () => { spawnError = true; state.errorCode = 'ENCODER_START_FAILED'; state.running = false; resolve({ code: null, signal: null }); });
    proc.once('close', (code, signal) => { state.running = false; resolve({ code, signal }); });
  });
  log.on('error', () => { state.errorCode ||= 'LOG_WRITE_FAILED'; state.running = false; proc.kill('SIGTERM'); });
  proc.stderr.pipe(log);
  proc.stdin.on('error', () => { state.errorCode ||= 'ENCODER_PIPE_FAILED'; state.running = false; });
  try { await once(proc, 'spawn'); }
  catch (_) { log.end(); await releaseLock(); throw new Error('FFmpeg could not start'); }
  let previousImage = first, encodedFrames = 0;
  async function emitFrame(image) {
    if (proc.stdin.destroyed || proc.stdin.writableEnded) throw new Error('ENCODER_EXITED');
    if (!proc.stdin.write(image.bytes)) {
      await Promise.race([once(proc.stdin, 'drain'), closed.then(() => { throw new Error('ENCODER_EXITED'); })]);
    }
    encodedFrames++;
  }
  async function acceptFrame(image, t) {
    if (image.codec !== first.codec || image.width !== first.width || image.height !== first.height) {
      throw new Error('CAPTURE_FORMAT_CHANGED');
    }
    // Sample-and-hold on a measured output clock, not pipe parser wall-clock arrival.
    // Duplicated output frames are not additional captured UI frames.
    const target = Math.floor(t * fps);
    while (encodedFrames < target) await emitFrame(previousImage);
    previousImage = image;
    state.frameTimes.push(t); state.frames++;
  }
  // The loop only reads screenshots; it cannot authorize or dispatch UI actions.
  const loop = (async () => {
    try {
      await acceptFrame(first, 0);
      while (state.running) {
        const elapsed = (performance.now() - started) / 1000;
        if (elapsed >= maxSeconds) { state.stopReason = 'max_duration'; state.running = false; break; }
        const last = state.frameTimes.at(-1) || 0;
        await sleep(Math.max(0, minIntervalMs - (elapsed - last) * 1000));
        if (!state.running) break;
        const image = inspectImage(await captureWithTimeout(captureFrame, frameTimeoutMs));
        if (!state.running) break;
        await acceptFrame(image, (performance.now() - started) / 1000);
      }
    } catch (e) {
      state.errorCode ||= ['CAPTURE_TIMEOUT', 'CAPTURE_FORMAT_CHANGED', 'ENCODER_EXITED'].includes(e.message) ? e.message : 'CAPTURE_FAILED';
      state.stopReason ||= 'capture_error'; state.running = false;
    } finally {
      state.captureSeconds ||= (performance.now() - started) / 1000;
      if (!state.errorCode) {
        try {
          while (encodedFrames < Math.max(1, Math.ceil(state.captureSeconds * fps))) await emitFrame(previousImage);
        } catch (_) { state.errorCode ||= 'ENCODER_PIPE_FAILED'; }
      }
      state.encodedFrames = encodedFrames;
      state.outputTiming = 'measured-sample-and-hold-cfr';
      if (!proc.stdin.destroyed && !proc.stdin.writableEnded) proc.stdin.end();
    }
  })();
  let stopping;
  return {
    state,
    mark(label) {
      if (typeof label !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(label)) throw new Error('Event labels must be short safe identifiers, not user text or URLs');
      state.events.push({ label, seconds: (performance.now() - started) / 1000, frameCount: state.frames });
    },
    stop() {
      if (stopping) return stopping;
      state.running = false; state.stopReason ||= 'manual';
      state.captureSeconds ||= (performance.now() - started) / 1000;
      stopping = (async () => {
        await loop;
        if (!proc.stdin.destroyed && !proc.stdin.writableEnded) proc.stdin.end();
        let result = await deadline(closed, encoderCloseTimeoutMs);
        if (!result) {
          state.errorCode ||= 'ENCODER_CLOSE_TIMEOUT'; proc.kill('SIGTERM');
          result = await deadline(closed, 2000);
          if (!result) { proc.kill('SIGKILL'); result = await closed; }
        }
        if (!log.writableFinished && !log.destroyed) await new Promise(resolve => { log.once('error', resolve); log.end(resolve); });
        const last = state.frameTimes.at(-1) || 0;
        state.observedCaptureFps = state.frames > 1 && last > 0 ? (state.frames - 1) / last : null;
        state.maxFrameGapSeconds = state.frameTimes.length > 1 ? state.frameTimes.slice(1).reduce((max, t, i) => Math.max(max, t - state.frameTimes[i]), 0) : null;
        state.elapsedSeconds = (performance.now() - started) / 1000;
        state.encoderExitCode = result.code;
        state.status = state.errorCode || spawnError || result.code !== 0 ? 'failed' : 'recorded-not-reviewed';
        state.cfrDoesNotProveCaptureFps = true;
        try { await fs.writeFile(metaPath, JSON.stringify(state, null, 2) + '\n', { flag: 'wx' }); }
        finally { await releaseLock(); }
        return state;
      })();
      return stopping;
    }
  };
}
