#!/usr/bin/env python3
"""Offline sentence-timed scheduling. Does not synthesize, listen, render or operate UI."""
import argparse
import json
import math
from pathlib import Path
import subprocess
import sys

DEFAULTS = {
    'safety_factor': 1.08, 'per_sentence_extra_seconds': .35,
    'lead_seconds': .65, 'between_sentences_seconds': .45,
    'tail_seconds': 1.35, 'clear_seconds': .2,
}
METHODS = {'local_tts', 'online_tts', 'presenter_recording', 'user_reported', 'manual_estimate', 'illustrative'}


def finite(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < minimum:
        raise ValueError(name + ' must be finite and >= ' + str(minimum))
    return float(value)


def local_audio(root, value):
    if not isinstance(value, str) or not value or '\\' in value or ':' in value:
        raise ValueError('timing audio must use a local relative path')
    p = Path(value)
    if p.is_absolute() or '..' in p.parts:
        raise ValueError('timing audio may not be absolute or escape the root')
    result = (root / p).resolve()
    if not result.is_relative_to(root.resolve()):
        raise ValueError('timing audio symlink escapes the root')
    return result


def probe_duration(path):
    result = subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)],
                            check=True, capture_output=True, text=True, timeout=30)
    obj = json.loads(result.stdout)
    if not any(s.get('codec_type') == 'audio' for s in obj.get('streams', [])):
        raise ValueError('timing reference has no audio stream')
    duration = finite(float(obj['format']['duration']), 'probed audio duration')
    if duration <= 0:
        raise ValueError('timing audio is empty')
    return duration


def build_schedule(data, root, probe_audio=False, probe_fn=probe_duration):
    if not isinstance(data, dict):
        raise ValueError('input must be an object')
    fps = data.get('fps', 30)
    if isinstance(fps, bool) or not isinstance(fps, int) or not 1 <= fps <= 120:
        raise ValueError('fps must be an integer from 1 to 120')
    mode = data.get('audio_mode', 'silent')
    if mode not in ('silent', 'narrated'):
        raise ValueError('audio_mode must be silent or narrated')
    supplied = data.get('settings', {})
    if not isinstance(supplied, dict) or set(supplied) - set(DEFAULTS):
        raise ValueError('unknown or invalid timing settings')
    settings = dict(DEFAULTS, **supplied)
    for key, value in settings.items():
        finite(value, key, 1 if key == 'safety_factor' else 0)
    ceil_frame = lambda v: math.ceil(v * fps - 1e-9)
    motion_frames = lambda v: max(1, round(v * fps)) if v > 0 else 0
    seconds = lambda f: f / fps
    lead = ceil_frame(settings['lead_seconds'])
    gap = ceil_frame(settings['between_sentences_seconds'])
    tail = ceil_frame(settings['tail_seconds'])
    clear = min(tail, ceil_frame(settings['clear_seconds']))
    blocks_in = data.get('blocks')
    if not isinstance(blocks_in, list) or not blocks_in:
        raise ValueError('blocks must be a nonempty array')
    cursor = 0
    ids, block_ids = set(), set()
    blocks, cues, motions, targets, warnings = [], [], [], [], []
    ready = True
    for block in blocks_in:
        bid = block.get('id') if isinstance(block, dict) else None
        if not isinstance(bid, str) or not bid or bid in block_ids:
            raise ValueError('each block requires a unique id')
        block_ids.add(bid)
        sentences = block.get('sentences')
        if not isinstance(sentences, list) or not sentences:
            raise ValueError(bid + ': sentences must be a nonempty array')
        refs = []
        for sentence in sentences:
            sid = sentence.get('id') if isinstance(sentence, dict) else None
            if not isinstance(sid, str) or not sid or sid in ids:
                raise ValueError('sentence ids must be globally unique')
            ids.add(sid)
            text = sentence.get('display_text')
            if not isinstance(text, str) or not text.strip():
                raise ValueError(sid + ': display_text is required')
            spoken = sentence.get('spoken_text', text)
            if not isinstance(spoken, str) or not spoken.strip():
                raise ValueError(sid + ': spoken_text must be nonempty')
            ref = sentence.get('timing_reference', {})
            if not isinstance(ref, dict) or ref.get('method') not in METHODS:
                raise ValueError(sid + ': declare an explicit timing reference method')
            method, relative = ref['method'], ref.get('path')
            path = local_audio(root, relative) if relative is not None else None
            probed = False
            if probe_audio and path is not None:
                if not path.is_file():
                    raise ValueError(sid + ': timing audio is missing')
                duration = probe_fn(path)
                duration = finite(duration, sid + ' audio duration')
                probed = True
            else:
                duration = finite(ref.get('duration_seconds'), sid + ' declared duration')
            if duration <= 0:
                raise ValueError(sid + ': duration must be positive')
            evidence = 'audio-probed' if probed else ('user-reported' if method == 'user_reported' else 'declared-not-probed')
            if method in ('manual_estimate', 'illustrative') or (not probed and method != 'user_reported'):
                ready = False
                warnings.append(sid + ': ' + method + ' / ' + evidence + '; not verified reading evidence')
            if mode == 'narrated' and ref.get('role') != 'delivery':
                ready = False
                warnings.append(sid + ': timing reference is not marked as the final delivery voice')
            refs.append(dict(id=sid, display_text=text, spoken_text=spoken, reference_seconds=duration,
                             reference_method=method, evidence=evidence, reference_path=relative,
                             budget_frames=ceil_frame(duration * settings['safety_factor'] + settings['per_sentence_extra_seconds'])))
        before = motion_frames(finite(block.get('motion_before_seconds', 0), bid + ' motion_before'))
        after = motion_frames(finite(block.get('motion_after_seconds', 0), bid + ' motion_after'))
        start = cursor
        if before:
            motions.append(dict(block=bid, phase='before', start=seconds(cursor), end=seconds(cursor + before)))
        cursor += before
        hold_start = cursor
        required = lead + sum(x['budget_frames'] for x in refs) + gap * (len(refs)-1) + tail
        old_hold = block.get('existing_hold_seconds')
        hold_frames = max(required, ceil_frame(finite(old_hold, bid + ' existing hold')) if old_hold is not None else 0)
        hold_end = hold_start + hold_frames
        reading_cursor = hold_start + lead
        current = []
        for index, ref in enumerate(refs):
            reading_end = reading_cursor + ref['budget_frames']
            end = reading_end + gap if index < len(refs)-1 else hold_end - clear
            cue = dict(ref, block=bid, start_frame=reading_cursor, reading_end_frame=reading_end,
                       end_frame=end, start=seconds(reading_cursor), reading_end=seconds(reading_end),
                       end=seconds(end), hold_start=seconds(hold_start), hold_end=seconds(hold_end))
            assert hold_start <= reading_cursor < reading_end <= end <= hold_end
            current.append(cue)
            cues.append(cue)
            reading_cursor = reading_end + gap
        groups = block.get('highlight_groups', [])
        if not isinstance(groups, list):
            raise ValueError(bid + ': highlight_groups must be an array')
        local_ids = [x['id'] for x in current]
        group_ids = set()
        for group in groups:
            gid = group.get('id') if isinstance(group, dict) else None
            if not isinstance(gid, str) or not gid or gid in group_ids:
                raise ValueError(bid + ': highlight groups require unique ids')
            group_ids.add(gid)
            try:
                first = local_ids.index(group['from_sentence'])
                last = local_ids.index(group.get('through_sentence', group['from_sentence']))
            except (ValueError, KeyError):
                raise ValueError(bid + ': unknown sentence in highlight group')
            if last < first:
                raise ValueError(bid + ': reversed highlight sentence window')
            a = hold_start + min(ceil_frame(.2), lead) if first == 0 else current[first]['start_frame']
            b = current[last]['end_frame']
            targets.append(dict(id=bid+'/'+gid, block=bid, target_anchor=group.get('target_anchor', ''),
                                from_sentence=local_ids[first], through_sentence=local_ids[last], start=seconds(a), end=seconds(b)))
        cursor = hold_end
        if after:
            motions.append(dict(block=bid, phase='after', start=seconds(cursor), end=seconds(cursor+after)))
        cursor += after
        speech_sum = sum(x['reference_seconds'] for x in refs)
        blocks.append(dict(id=bid, title=block.get('title', ''), start=seconds(start), hold_start=seconds(hold_start),
                           hold_end=seconds(hold_end), end=seconds(cursor), start_frame=start, end_frame=cursor,
                           reference_speech_seconds=speech_sum, stable_seconds=seconds(hold_frames),
                           previous_stable_seconds=old_hold,
                           previous_reading_deficit_seconds=max(0, speech_sum-old_hold) if old_hold is not None else None))
    for interval in cues + targets:
        for motion in motions:
            if interval['start'] < motion['end']-1e-9 and interval['end'] > motion['start']+1e-9:
                raise ValueError('reading or highlight overlaps actual operation')
    return dict(schema='japanese-readalong-schedule', schema_version=1, audio_mode=mode, fps=fps,
                duration=seconds(cursor), total_frames=cursor, settings=settings, blocks=blocks,
                captions=cues, motions=motions, target_windows=targets, warnings=warnings,
                ready_for_timing_review=ready, human_listening_verified=False,
                limitations='Schedule only. No generated media, semantic/audio-content verification, voice approval or presenter rehearsal is implied.')


def markdown_report(plan):
    lines = ['# 逐句朗读排期', '', '总长：%.3fs / %d frames / %dfps' % (plan['duration'], plan['total_frames'], plan['fps']),
             '朗读证据可用于时序核对：' + str(plan['ready_for_timing_review']),
             '这不是成片、已试听证明或真人语速保证。', '',
             '|画面段|原稳定时间|参考朗读合计|新稳定时间|片段总长|', '|---|---:|---:|---:|---:|']
    for b in plan['blocks']:
        title = str(b['title'] or b['id']).replace('|', '\\|').replace('\n', ' ')
        old = '未提供' if b['previous_stable_seconds'] is None else '%.3fs' % b['previous_stable_seconds']
        lines.append('|%s|%s|%.3fs|%.3fs|%.3fs|' % (title, old, b['reference_speech_seconds'], b['stable_seconds'], b['end']-b['start']))
    if plan['warnings']:
        lines += ['', '## 未验证项'] + ['- '+x for x in plan['warnings']]
    return '\n'.join(lines)+'\n'


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input', type=Path)
    ap.add_argument('--root', type=Path)
    ap.add_argument('--probe', action='store_true', help='Use actual local audio durations via FFprobe')
    ap.add_argument('--output', type=Path, help='Write a NEW schedule JSON; never overwrite')
    ap.add_argument('--report', type=Path, help='Optional NEW Markdown comparison report')
    args = ap.parse_args()
    try:
        outputs = [p for p in (args.output, args.report) if p is not None]
        if len({p.resolve() for p in outputs}) != len(outputs) or any(p.exists() for p in outputs):
            raise ValueError('output paths must be distinct, new files')
        obj = json.loads(args.input.read_text(encoding='utf-8'))
        result = build_schedule(obj, (args.root or args.input.parent).resolve(), args.probe)
        for p, value in [(args.output, json.dumps(result, ensure_ascii=False, indent=2)+'\n'), (args.report, markdown_report(result))]:
            if p is not None:
                p.parent.mkdir(parents=True, exist_ok=True)
                with p.open('x', encoding='utf-8') as stream:
                    stream.write(value)
        if args.output is None:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({'output': str(args.output), 'duration': result['duration'], 'ready_for_timing_review': result['ready_for_timing_review'], 'warning_count': len(result['warnings'])}, ensure_ascii=False))
        return 0
    except (OSError, ValueError, TypeError, KeyError, subprocess.SubprocessError) as exc:
        print(json.dumps({'status': 'failed', 'error': str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
