"""Offline local-voice regression tests; synthetic PCM, no downloaded models."""
import copy
import io
import json
import math
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch
import wave

S = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(S/'scripts'))
import voicevox_narrate as v


def sine_wav(seconds=.5, rate=24000):
    buf = io.BytesIO()
    with wave.open(buf, 'wb') as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(rate)
        f.writeframes(b''.join(struct.pack('<h', int(2000*math.sin(2*math.pi*220*i/rate)))
                              for i in range(round(seconds*rate))))
    return buf.getvalue()


def plan():
    return {'endpoint': 'http://127.0.0.1:12345', 'mode': 'narration',
            'speaker_name': 'Test Voice', 'style_name': 'normal',
            'voice_approved': True, 'terms_reviewed': True,
            'terms_url': 'https://example.org/terms', 'credit': '音声：テスト用の架空音声',
            'duration': 4.0, 'minimum_tail': .25, 'settings': {'speedScale': .9},
            'cues': [{'id': 'cue-1', 'display_text': 'Save を確認します。',
                      'spoken_text': 'セーブを確認します。',
                      'start': 1.0, 'end': 2.5, 'stable_start': .5, 'stable_end': 3.0}]}


def fake_request(endpoint, path, params=None, body=None):
    if path == '/speakers':
        return json.dumps([{'name': 'Test Voice', 'styles': [{'name': 'normal', 'id': 77}]}]).encode()
    if path == '/version':
        return b'"test-engine"'
    if path == '/audio_query':
        assert params['text'] == 'セーブを確認します。'
        return json.dumps({'kana': 'セエブオカクニンシマス', 'accent_phrases': []}).encode()
    if path == '/synthesis':
        q = json.loads(body)
        assert params['speaker'] == 77 and q['speedScale'] == .9
        assert q['outputSamplingRate'] == 24000 and q['outputStereo'] is False
        return sine_wav()
    raise AssertionError(path)


class LocalVoiceTests(unittest.TestCase):
    def test_reject_external_or_credentialed_origins(self):
        for value in ['https://example.org', 'http://192.168.1.8:50000',
                      'http://user:pw@localhost:50000', 'http://localhost:50000/path',
                      'http://localhost:50000?text=sensitive']:
            with self.assertRaises(ValueError): v.local_endpoint(value)
        self.assertEqual(v.local_endpoint('http://127.0.0.1:50000/'), 'http://127.0.0.1:50000')
        self.assertEqual(v.local_endpoint('http://[::1]:50000'), 'http://[::1]:50000')

    def test_terms_and_voice_approval_are_separate(self):
        p = plan(); p['terms_reviewed'] = False
        with self.assertRaises(ValueError): v.validate_plan(p)
        p = plan(); p['voice_approved'] = False
        with self.assertRaises(ValueError): v.validate_plan(p)
        p['mode'] = 'audition'
        self.assertEqual(v.validate_plan(p), 'audition')

    def test_overlap_outside_hold_and_duplicate_ids_rejected(self):
        p = plan(); p['cues'][0]['stable_end'] = 2.0
        with self.assertRaises(ValueError): v.validate_plan(p)
        p = plan(); p['cues'].append(copy.deepcopy(p['cues'][0]))
        with self.assertRaises(ValueError): v.validate_plan(p)
        p['cues'][1]['id'] = 'cue-2'
        with self.assertRaises(ValueError): v.validate_plan(p)

    def test_invalid_numeric_and_path_traversal_rejected(self):
        for x in [-1, float('nan'), True]:
            p = plan(); p['cues'][0]['start'] = x
            with self.assertRaises(ValueError): v.validate_plan(p)
        p = plan(); p['cues'][0]['id'] = '../escaped'
        with self.assertRaises(ValueError): v.validate_plan(p)
        p = plan(); p['settings']['outputStereo'] = True
        with self.assertRaises(ValueError): v.validate_plan(p)

    def test_voice_resolved_from_current_response_not_project_id(self):
        self.assertEqual(v.resolve_speaker([{'name':'A','styles':[{'name':'normal','id':42}]}], 'A', 'normal'),42)
        with self.assertRaises(ValueError): v.resolve_speaker([], 'A', 'normal')

    def test_narration_generates_exact_full_timeline_and_preserves_display(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(v, 'request', side_effect=fake_request):
            out = Path(tmp)/'new'; r = v.synthesize(plan(), out)
            self.assertTrue(r['timeline_ready']); self.assertFalse(r['human_listening_verified'])
            self.assertEqual(r['cues'][0]['display_text'], 'Save を確認します。')
            self.assertEqual(r['resolved_speaker_id'], 77)
            with wave.open(str(out/'timeline-raw.wav')) as f:
                self.assertEqual(f.getnframes(), 4*24000)
                samples = struct.unpack('<'+'h'*f.getnframes(), f.readframes(f.getnframes()))
            self.assertFalse(any(samples[:24000])); self.assertTrue(any(samples[24000:36000]))
            self.assertFalse(any(samples[36000:]))
            self.assertTrue((out/'音声クレジット.txt').exists())

    def test_audition_does_not_create_full_timeline(self):
        p=plan(); p['mode']='audition'; p['voice_approved']=False
        with tempfile.TemporaryDirectory() as tmp, patch.object(v, 'request', side_effect=fake_request):
            out=Path(tmp)/'sample'; r=v.synthesize(p,out)
            self.assertFalse(r['timeline_ready']); self.assertFalse((out/'timeline-raw.wav').exists())

    def test_overrun_keeps_incomplete_manifest_but_never_truncates(self):
        p=plan(); p['cues'][0]['end']=1.6
        with tempfile.TemporaryDirectory() as tmp, patch.object(v, 'request', side_effect=fake_request):
            out=Path(tmp)/'overrun'
            with self.assertRaises(ValueError): v.synthesize(p,out)
            self.assertFalse((out/'timeline-raw.wav').exists())
            self.assertFalse(json.loads((out/'manifest.json').read_text())['timeline_ready'])
            with wave.open(str(out/'cue-1.wav')) as f:self.assertEqual(f.getnframes(),12000)
            self.assertTrue((out/'音声クレジット.txt').exists())

    def test_existing_output_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileExistsError): v.synthesize(plan(),Path(tmp))

    def test_mixed_rate_refused_before_timeline_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            a=Path(tmp)/'a.wav'; b=Path(tmp)/'b.wav'; o=Path(tmp)/'mix.wav'
            a.write_bytes(sine_wav(rate=24000)); b.write_bytes(sine_wav(rate=48000))
            with self.assertRaises(ValueError):
                v.build_timeline([{'id':'a','audio':a,'start':0,'end':1},
                                  {'id':'b','audio':b,'start':2,'end':3}],4,o)
            self.assertFalse(o.exists())


if __name__ == '__main__': unittest.main()
