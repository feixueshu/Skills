"""Portable, offline regression checks; no client recordings or voice service calls."""
import copy
import json
from pathlib import Path
import random
import shutil
import subprocess
import sys
import tempfile
import unittest
import wave

S = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(S/'scripts'))
from plan_readalong import build_schedule, local_audio
from check_demo_plan import validate
from review_frames import review_points, verify_final_streams


class TimingTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((S/'assets/readalong.example.json').read_text())
        self.silent = json.loads((S/'assets/demo-plan-silent.example.json').read_text())

    def test_no_uniform_hold_and_actions_not_reading_time(self):
        p = build_schedule(self.data, S)
        b = p['blocks'][0]
        self.assertGreater(b['stable_seconds'], b['previous_stable_seconds'])
        self.assertAlmostEqual(b['hold_start']-b['start'], 1.2)
        self.assertAlmostEqual(b['end']-b['hold_end'], .5)
        for c in p['captions']:
            self.assertGreaterEqual(c['start'], b['hold_start'])
            self.assertLessEqual(c['reading_end'], c['end'])
            self.assertLessEqual(c['end'], b['hold_end'])
            self.assertGreaterEqual(c['reading_end']-c['start']+1e-8, c['reference_seconds'])

    def test_save_target_follows_its_sentence_not_midpoint(self):
        p = build_schedule(self.data, S)
        save = next(t for t in p['target_windows'] if t['id'].endswith('/save'))
        cue = next(c for c in p['captions'] if c['id']=='settings-3')
        self.assertEqual(save['start'], cue['start'])
        first = next(t for t in p['target_windows'] if t['id'].endswith('/recipient'))
        self.assertLessEqual(first['end'], save['start'])

    def test_display_and_spoken_form_remain_distinct(self):
        p = build_schedule(self.data, S)
        c = p['captions'][2]
        self.assertIn('Save', c['display_text'])
        self.assertIn('セーブ', c['spoken_text'])
        self.assertEqual(p['captions'][0]['display_text'], self.data['blocks'][0]['sentences'][0]['display_text'])

    def test_example_durations_are_not_claimed_as_measured(self):
        p = build_schedule(self.data, S, probe_audio=True)
        self.assertFalse(p['ready_for_timing_review'])
        self.assertFalse(p['human_listening_verified'])
        self.assertTrue(p['warnings'])

    def test_existing_longer_holds_not_shortened(self):
        self.data['blocks'][0]['existing_hold_seconds'] = 40
        p = build_schedule(self.data, S)
        self.assertEqual(p['blocks'][0]['stable_seconds'], 40)

    def test_duplicates_bad_targets_and_invalid_numbers_rejected(self):
        bad = copy.deepcopy(self.data)
        bad['blocks'][0]['sentences'][1]['id'] = 'settings-1'
        with self.assertRaises(ValueError):
            build_schedule(bad, S)
        bad = copy.deepcopy(self.data)
        bad['blocks'][0]['highlight_groups'][0]['from_sentence'] = 'missing'
        with self.assertRaises(ValueError):
            build_schedule(bad, S)
        for value in [-1, float('nan'), True]:
            bad = copy.deepcopy(self.data)
            bad['blocks'][0]['motion_before_seconds'] = value
            with self.assertRaises(ValueError):
                build_schedule(bad, S)

    def test_paths_do_not_escape_including_symlinks(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)/'root'
            root.mkdir()
            outside = Path(d)/'outside.wav'
            outside.write_bytes(b'test')
            for path in ['../outside.wav', str(outside), 'https://example.invalid/a.wav']:
                with self.assertRaises(ValueError):
                    local_audio(root, path)
            try:
                (root/'linked.wav').symlink_to(outside)
            except OSError:
                return
            with self.assertRaises(ValueError):
                local_audio(root, 'linked.wav')

    @unittest.skipUnless(shutil.which('ffprobe'), 'FFprobe not installed')
    def test_actual_audio_duration_supersedes_declared_guess(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            with wave.open(str(root/'voice.wav'), 'wb') as w:
                w.setparams((1, 2, 8000, 0, 'NONE', 'not compressed'))
                w.writeframes(b'\0\0'*(8000*2))
            data = {'fps':30, 'audio_mode':'silent', 'blocks':[{'id':'one', 'sentences':[{
                'id':'one-1', 'display_text':'設定を確認します。',
                'timing_reference':{'method':'local_tts','path':'voice.wav','duration_seconds':.5}}]}]}
            p = build_schedule(data, root, probe_audio=True)
            self.assertAlmostEqual(p['captions'][0]['reference_seconds'], 2, places=3)
            self.assertEqual(p['captions'][0]['evidence'], 'audio-probed')
            self.assertTrue(p['ready_for_timing_review'])
            self.assertFalse(p['human_listening_verified'])

    def test_narrated_mode_does_not_promote_reference_audio_to_final(self):
        data = copy.deepcopy(self.data)
        data['audio_mode'] = 'narrated'
        p = build_schedule(data, S)
        self.assertFalse(p['ready_for_timing_review'])
        self.assertTrue(any('final delivery voice' in x for x in p['warnings']))

    def test_random_frame_quantized_windows_are_serial_and_fit(self):
        rng = random.Random(43)
        for _ in range(30):
            blocks = []
            for i in range(rng.randrange(1,5)):
                ss = [{'id':f'b{i}-s{k}', 'display_text':'項目を確認します。',
                       'timing_reference':{'method':'user_reported','duration_seconds':rng.uniform(.05,9)}}
                      for k in range(rng.randrange(1,5))]
                blocks.append({'id':f'b{i}', 'motion_before_seconds':rng.random()*3,
                               'motion_after_seconds':rng.random()*2, 'sentences':ss})
            p = build_schedule({'fps':30,'blocks':blocks}, S)
            previous = 0
            for c in p['captions']:
                self.assertGreaterEqual(c['start']+1e-9, previous)
                self.assertLessEqual(c['reading_end'], c['end'])
                self.assertAlmostEqual(c['start']*30, round(c['start']*30), places=7)
                previous = c['end']
            self.assertAlmostEqual(p['duration']*30, p['total_frames'])

    def test_cli_never_overwrites(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            inp = root/'input.json'
            out = root/'existing.json'
            inp.write_text(json.dumps(self.data))
            out.write_text('keep this file')
            run = subprocess.run([sys.executable,str(S/'scripts/plan_readalong.py'),str(inp),'--output',str(out)],capture_output=True,text=True)
            self.assertNotEqual(run.returncode,0)
            self.assertEqual(out.read_text(),'keep this file')

    def test_narrated_legacy_plan_still_valid(self):
        old = json.loads((S/'assets/demo-plan.example.json').read_text())
        errors, _ = validate(old,S)
        self.assertEqual(errors,[])
        del old['audio_mode']
        self.assertEqual(validate(old,S)[0],[])

    def test_silent_mode_supports_reading_refs_without_delivery_narration(self):
        errors, warnings = validate(self.silent,S)
        self.assertEqual(errors,[])
        self.assertTrue(any('actual reading evidence' in w for w in warnings))
        bad = copy.deepcopy(self.silent)
        bad['steps'][0]['narration'] = {'start':2,'end':3,'path':'voice.wav','spoken_text':'確認します。'}
        self.assertTrue(any('silent plan' in e for e in validate(bad,S)[0]))

    def test_premature_subtitle_change_and_motion_overlap_rejected(self):
        bad = copy.deepcopy(self.silent)
        bad['steps'][0]['captions'][0]['reading_reference']['end'] = 7.1
        self.assertTrue(validate(bad,S)[0])
        bad = copy.deepcopy(self.silent)
        bad['motions'] = [{'start':3,'end':4}]
        self.assertTrue(any('overlaps motion' in e for e in validate(bad,S)[0]))

    def test_every_caption_has_reading_proof_points_and_no_phantom_action(self):
        p = review_points(self.silent)
        for c in self.silent['steps'][0]['captions']:
            phases = {x['phase'] for x in p if x.get('caption')==c['id']}
            self.assertTrue({'reading_start','reading_mid','reading_end','after_reference_reading'} <= phases)
        no_action = copy.deepcopy(self.silent)
        no_action['steps'][0]['hold_start'] = 0
        self.assertFalse(any(x['phase']=='action_mid' for x in review_points(no_action)))

    def test_final_audio_stream_mode_is_checked(self):
        info = {'format':{'duration':'14'},'streams':[{'codec_type':'video','width':1920,'height':1080,'r_frame_rate':'30/1'}]}
        self.assertEqual(verify_final_streams(self.silent,info)['audio_streams'],0)
        bad = copy.deepcopy(info)
        bad['streams'].append({'codec_type':'audio'})
        with self.assertRaisesRegex(ValueError,'Silent delivery'):
            verify_final_streams(self.silent,bad)
        narrated = copy.deepcopy(self.silent)
        narrated['audio_mode'] = 'narrated'
        with self.assertRaisesRegex(ValueError,'no audio'):
            verify_final_streams(narrated,info)


if __name__ == '__main__':
    unittest.main()
