# Demo production and resume record

- Audience / purpose / language:
- Task: new / silent / narration / audition / targeted revision / resume:
- Authoritative requirements, approved deck and latest user notes:
- Current baseline and outputs (private hashes if needed):
- Approved workflow, initial state, expected evidence per step:
- Storyboard: action → stable screen → sentence → target → result:
- Voice route, audition approval, terms version and credit:
- Measured reading/audio windows and action overhead:
- Authorized live mutations and explicit non-goals:
- Raw footage provenance, dimensions and sampling limitations:
- Final decode/stream/frame/semantic/playback/listening checks:
- Remaining human approval / unresolved limitations:
- Pause state and next safe action (no credentials):
- Customer share files versus private working files:
