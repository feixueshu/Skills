# Capture and timing

## Preflight and tool boundaries

Discover existing `ffmpeg`, `ffprobe`, Python, Node, and the chosen editor. Read the currently documented capture/control APIs; do not invent `startRecording()`, reuse an old CDP port, access hidden browser state, inject fake UI, or bypass a disabled GUI method. Missing tools, permissions, or licenses are concrete prerequisites, not permission to install or change the system silently.

Use one authorized app/window/tab where possible. Resolve login before recording. Avoid notifications, unrelated tabs, password managers, and authentication prompts. If changing notification/screen/microphone settings needs consent, obtain it. Verify source dimensions, CSS viewport/DPR, screenshot dimensions, and target coordinates in the same stable state.

Native controls may expose a checkbox as a button or a tiny hidden input behind a label. If a semantic click fails, inspect current visible controls before retrying. DOM presence is not visual readiness. Never cache element indices or highlight coordinates across page transitions.

## Optional callback encoder

`scripts/record_live_tab.mjs` exports a recorder that receives a permitted asynchronous `captureFrame` callback and encodes those real returned image bytes. It does not attach to a browser or operate UI. Read its export and parameters before integration. Use it only in an environment that permits its Node filesystem/process operations and the selected screenshot API. If the host disallows them, use a supported recorder instead.

Supply a fresh output path, an existing FFmpeg executable, and a callback for the already-authorized capture target. Record actual samples, measured capture duration, encoded frame count, limits, errors, and action markers. Stop capture and check encoder completion before consuming output. Do not put URLs or user text into event labels; safe short identifiers suffice. Fast motion needs adequate real sampling, not duplicated frames and a nominal 30-fps header.

## Sentence scheduling model

For each block, keep separate budgets for:

1. navigation/action and settling;
2. stable-screen lead;
3. measured sentence readings and inter-sentence pauses;
4. final viewing margin;
5. exit action and clearing stale overlays.

Use `assets/readalong.example.json` as an illustrative schema. Replace `timing_reference` with an actual audio path or clearly identified human timing. Paths are project-relative and must not escape the project. Reference narration is a proxy; mark it as such. In narrated mode, identify actual delivery audio as `role: delivery` where supported.

`plan_readalong.py` quantizes to frames, keeps action time separate, preserves longer existing holds, and can map highlight groups to sentence IDs. It does not synthesize audio, render video, or certify that speech means the same thing as subtitles. An illustrative duration produces a warning and is not measured evidence. It refuses to overwrite existing output.

The generated read-along schedule is **not** a `demo-plan.json`. Transfer the actual schedule into the editor, then build a demo validation plan using real source footage dimensions, source hold times, coordinates, caption windows, and narration/reading references.

## Validation plans

- `assets/demo-plan.example.json`: narrated schema.
- `assets/demo-plan-silent.example.json`: explicit silent schema, with reading references rather than a fake delivery track.
- `check_demo_plan.py`: source/path, coordinate, narration/reading, and caption-window checks; `--probe` uses FFprobe.
- `review_frames.py`: extracts scene, highlight, and sentence checkpoints from the **final output** and checks expected audio presence/absence.

Examples deliberately point to nonexistent footage and unconfirmed provenance. They are templates, not evidence that a recording exists. Check every sentence near start, middle, and after reading completion, every target change, and every action transition. An overlay must be hidden while its old target moves; a caption must remain through its own final phoneme and the required viewing margin.
