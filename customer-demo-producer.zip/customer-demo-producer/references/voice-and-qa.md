# Optional local voice, final QA, and delivery

## Voice route

Respect the user's chosen lawful voice and provider. A local VOICEVOX/Nemo engine is an option, not a mandatory dependency or a promise about every project's voice. Discover the actual installed engine, platform, version, model terms, and available `/speakers`. Do not claim a remembered release is the latest, assume an old speaker ID or port, expose an engine beyond loopback, or bypass operating-system protections.

Review the official terms for the actual engine/model version and intended use. Code licenses, voice-model licenses, generated-audio terms, and font licenses are distinct. The example terms reference is `https://voicevox.hiroshiba.jp/nemo/term/`; this skill does not give a legal approval or guarantee that terms will remain unchanged. Preserve required attribution with the distributed video, for example `音声：VOICEVOX Nemo` in a viewing guide or publication description when applicable. Invisible metadata alone may not reach recipients.

The bundled `voicevox_narrate.py` calls an **already authorized running local engine**. It does not download, install, or start one. Its plan supports `audition` and `narration`, resolves voice/style against the live engine, preserves display versus spoken text, emits measured sentence WAVs and a manifest, and constructs a full PCM timeline only when narration is approved and fits stable/caption windows. It does not claim human listening occurred.

```bash
python3 "$SKILL_DIR/scripts/voicevox_narrate.py" --list-voices "http://127.0.0.1:CURRENT_PORT"
python3 "$SKILL_DIR/scripts/voicevox_narrate.py" "$PROJECT/voice-plan.json" --output "$NEW_AUDIO_DIR"
```

Start from `assets/local-voice-audition.example.json`. Replace the placeholder port and discover a current voice/style. Keep `voice_approved: false` until actually approved; set `terms_reviewed` only after review. An audition request does not authorize a full track. Narration additionally needs a timeline duration and cue start/end/stable windows; inspect `--help`, script validation, and tests for the exact schema. Do not guess that every audio plan shares the same schema.

Listen for UI labels, abbreviations, numbers, percentages, units, place names, and negations. If a sentence is long, extend its real-frame hold or revise it with approval; do not time-stretch all speech to conceal an inadequate window.

## Final-file checks

Probe streams/duration/dimensions, then decode the actual final file:

```bash
ffprobe -v error -show_format -show_streams -of json "$FINAL_MP4"
ffmpeg -v error -i "$FINAL_MP4" -f null -
```

Check whether the requested silent file truly has no audio stream, or the narrated file has the intended track. Review sentence checkpoints, target changes, first/last words, caption-safe areas, privacy masks, content accuracy, and the actual business path. Watch the whole final film at normal speed and listen to the whole track. Automated success is not human listening approval.

For audio-only updates to an approved silent cut, copy the approved video stream when actual synchronization permits. Do not use `-shortest` blindly to hide missing audio or silently truncate the approved ending. Recheck the resulting file, not just input lengths.

## Privacy and release

Package only authorized deliverables and required credits. Do not distribute raw authentication screens, customer metadata, logs, wallet files, tokens, local engine binaries, models, system fonts, or machine-specific paths. If a source clip needs redaction, verify the mask throughout movement/transitions, not just a midpoint.

Keep private QA and the editable project outside the customer share directory. Store file hashes and source/approval mappings privately; a hash detects accidental changes, not semantic correctness or a digital signature. A new revision must identify what changed, what stayed approved, what was technically checked, and what still requires human review.
