---
name: customer-demo-producer
description: Create or revise customer-facing software walkthrough videos from real UI recordings, with sentence-timed captions, synchronized highlights, optional Japanese narration, evidence-based result scenes, and reproducible delivery checks. Use for new demos, silent or narrated editions, voice auditions, targeted revisions, or resuming production; not for fabricated UI, application development, or non-operational promotional films.
---

# Customer Demo Producer

Help the viewer understand **where to start, what happened, why, and where to verify the result**. Reuse approved production practices, not old customer content, resource identities, credentials, coordinates, or approvals. Honor the current user's language, tools, voice choice, and scope. Japanese business narration is a supported profile, not a universal requirement.

This package combines production orchestration and the portable recording/timing/QA helpers. It does not require a separately installed `japanese-demo-recording` skill.

## Read only what the task needs

- [Capture and timing](references/capture-and-timing.md): real UI capture, callback encoder, sentence scheduling, and timing plans.
- [Voice and delivery QA](references/voice-and-qa.md): optional local VOICEVOX/Nemo, audition, pronunciation, final-file review, and delivery.
- [Brief and resume record](assets/demo-brief.md): lightweight project state and acceptance gates.
- For new/edited slides, use the current host presentation workflow and, if available and relevant, `customer-presentation-producer`. A video-only request does not authorize changing the deck.
- If HyperFrames is installed and selected by the host workflow, read its current entry instructions and existing project rules before editing/rendering. Otherwise use the user's requested editor or an existing permitted toolchain. Never pretend a particular recorder or rendering API exists.

## 1. Select the exact task and authoritative baseline

Distinguish a new demo, silent edition, narrated edition, audition only, targeted correction, slides-only change, or resumed work. Use the latest user edits, explicit file choices, and release manifest—not the largest version number or modification time alone. Latest PowerPoint notes outrank old exported scripts. Preserve originals and produce a new version.

Record audience, objective, source artifacts, approved business path, expected result for each step, target duration, audio mode, and authorized side effects. Infer reliable context rather than repeating answered questions. Ask only if uncertainty affects authenticity, safety, or a material decision.

If the user asked for slides first and approval before recording, honor that gate. If the deck is already approved and only the video is requested, proceed without restarting the entire review. Historical timing or male-voice preferences are configurable examples, not constraints on another project.

A production request is not blanket business authorization. Login does not authorize deletion, pushing, deployment, purchases, account/permission changes, or public disclosure. Existing authorizations do not carry across projects. Use approved local secret channels; never print or package credentials.

## 2. Build a verifiable storyboard

Map each step:

`step → real action → stable UI state → explanation sentence → highlight target → expected evidence`

Follow the approved operation path. If the guide says Git clone/pull, do not substitute ZIP import or direct editing simply because it looks similar. Prepare an appropriate starting state; an “initial release” scene must not secretly be an update to an existing populated target. Resetting branches or deleting resources requires current authorization; never clean a real environment just to obtain nicer footage.

Show concrete evidence: actual before/after names, excluded fields, retained IDs, file diffs, target model and layer, or comparable business results—not just counts or a success toast. A separately tested result must have project evidence or be explicitly attributed to the user. Do not imply it was recorded or tested by the assistant.

Run a short capture containing navigation, an action, and a result before recording the full sequence. Check actual sample cadence, dimensions, legibility, sensitive areas, and whether important transitions were captured. If no real capture capability is available, state the missing capability and request footage; do not synthesize UI as a substitute.

## 3. Capture real actions and plan readable time

Use current documented browser/native-app controls and recording APIs. Observe the current UI before clicking. Refresh target geometry after navigation, scrolling, menus, or viewport changes. Capture pixels from the real application; do not replace labels, values, loading states, or results with a fabricated interface.

A 30-fps output container does not prove 30-fps live sampling. The optional callback recorder encodes measured sample-and-hold footage and records timing metadata. Prefer an existing authorized native recorder for fast motion if screenshot sampling cannot resolve it.

Remove meaningless waits but retain important menus, file selection, and operations long enough to understand. Freeze real frames when helpful and identify the freeze, for example `解説のため一時停止`. Do not slow the whole film mechanically to fix a few short captions.

## 4. Synchronize sentences, visuals, and highlights

Give each sentence a stable visible window. An introductory sentence may precede an action; a result claim must not precede the visible result. Show the relevant caption promptly when the stable target is ready.

- **Silent mode:** time a reference read and add viewing margin. Action/loading/scrolling time is separate from reading time. TTS is a timing proxy, not a human rehearsal, and must not accidentally become an audio stream in the silent deliverable.
- **Narrated mode:** measure actual sentence audio. Check first/last phonemes, pauses, and tail room. Keep display text separate from spoken readings; verify acronyms, English UI, numbers, units, and negations.
- Keep the subtitle visible until its sentence finishes. Switch highlights at the explanatory sentence, not halfway through an arbitrary scene. Hide stale boxes during scrolling, loading, animation, or page changes; show them after the new target is stable.
- Use a restrained callout system without covering labels, buttons, or evidence. For dense UIs, enlarge/crop real pixels, never redraw them. Avoid persistent arrows pointing at obsolete positions.
- Do not impose uniform ten-second holds, subtract operation time from reading time, or speed up a voice to conceal a scheduling deficit.

An optional Japanese technical-demo starting profile is 1920×1080, 30-fps output, dark blue `#14222D`, yellow `#FFC83D`, white text, approximately 4-pixel outlines and 30–36-pixel captions in a separate bottom band. Verify actual font support and safe areas. The user's brand and approved composition take precedence. No music, flashy transitions, or unrelated ending is needed unless requested.

## 5. Audition before generating full narration

Use a user-provided track, an approved available voice service, or an explicitly selected local engine. Generate a short representative audition first, including difficult terminology and a negative sentence. Confirm naturalness, pronunciation, licensing, and user preference before rendering the whole film. If a voice is rejected, changing only its speed is not a new voice.

Ask for authentication only for the selected service. Do not make an unrelated cloud login a prerequisite for a local route. Engine code, voice models, fonts, and generated audio can have different terms; verify the versions actually used and carry any required credit with the video. Never bundle engine/model binaries, system fonts, or credentials in a reusable skill.

For an approved silent film that only needs audio, keep the approved video unchanged when synchronization permits; copy the video stream during muxing rather than re-rendering all visuals unnecessarily.

## 6. Revise narrowly and resume safely

Translate feedback into object/timecode, expected behavior, and the smallest necessary change. Keep approved sections intact. Determine whether a correction requires a new caption, a new hold, a highlight retime, an audio replacement, or genuinely new live footage. Recheck the changed boundaries and any downstream timing effects.

On pause, preserve the editable project and record the authoritative files, completed checks, unverified items, environment state without secrets, authorized scope, and next action. On resume, inspect the current files and UI; do not reuse stale tab IDs, coordinates, ports, or hidden assumptions. Do not resume work after the user explicitly pauses it.

## 7. Check the final file, then deliver

Check the **actual final MP4**, not only draft snapshots: full decode, dimensions, duration, audio-mode/streams, caption rendering, phoneme boundaries, sentence start/midpoint/reading-end frames, every target switch, all action transitions, and privacy masks. A structural checker cannot certify semantic truth, current licensing, or acceptable pronunciation.

Watch the final cut end-to-end at normal speed and listen to all narration. A sample-frame review cannot establish full-watch approval. If human listening, native playback, or end-to-end review was not completed, identify the exact remaining check.

Deliver only requested files: usually final MP4, optionally SRT, the approved deck, source archive, and a short viewing/credit guide. If captions are burned in, advise disabling duplicate player-side SRT. Keep private QA, raw captures, timing-only audio, credentials, and stale scripts out of the customer ZIP. Keep an editable project and a private hash/version manifest for reproducibility. Explicitly separate completed production, technical checks, user-reported results, and remaining human approval.

## Included helper commands

The Python helpers use the standard library. Media probes/extraction additionally require existing FFprobe/FFmpeg. The JavaScript callback encoder needs a supported Node environment and existing FFmpeg; it does not select or operate a browser.

```bash
python3 "$SKILL_DIR/scripts/plan_readalong.py" "$PROJECT/readalong.json" --root "$PROJECT" --probe --output "$PROJECT/new-schedule.json"
python3 "$SKILL_DIR/scripts/check_demo_plan.py" "$PROJECT/demo-plan.json" --root "$PROJECT" --probe
python3 "$SKILL_DIR/scripts/review_frames.py" "$PROJECT/demo-plan.json" --video "$FINAL_MP4" --output "$NEW_QA_DIR"
python3 -m unittest discover -s "$SKILL_DIR/tests" -v
```

Example assets intentionally contain no footage/audio. Illustrative durations, coordinates, voice settings, and unconfirmed provenance must be replaced and verified; an example is not a production-ready validation pass.
