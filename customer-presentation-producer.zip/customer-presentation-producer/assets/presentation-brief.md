# Presentation working brief

- Audience, purpose, language:
- Authoritative requirement and current source deck:
- Latest user edits and protected baseline:
- Template/brand and series reference:
- Allowed changes / non-goals:
- Approved workflow and expected evidence:
- Customer questions and slide outline:
- Required editions and notes profile:
- Slide + demo + switching + reserve budget:
- Live actions explicitly authorized:
- Product sources and verification dates:
- Render/native-app/notes/link checks completed:
- Remaining limitations / human approval:
- Current delivery files and private manifest:
