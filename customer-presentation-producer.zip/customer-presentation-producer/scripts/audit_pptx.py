#!/usr/bin/env python3
"""Read-only PPTX notes and conservative package-delta audit; Python stdlib only.

Does not render slides, mutate files, certify privacy, or bypass protection.
Reports omit note text. --report must not overwrite an existing file.
"""
import argparse
import hashlib
import json
import posixpath
import re
import sys
import zipfile
from pathlib import Path
from urllib.parse import unquote
from xml.etree import ElementTree as ET

NS = {
    'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
}
HEADINGS = {'【説明時間の目安】', '【読み上げ】'}
NOTES_RE = re.compile(r'^ppt/notesSlides/notesSlide[^/]*\.xml$')
VISUAL_PREFIXES = (
    'ppt/slides/', 'ppt/slideLayouts/', 'ppt/slideMasters/', 'ppt/theme/',
    'ppt/media/', 'ppt/charts/', 'ppt/embeddings/', 'ppt/drawings/',
    'ppt/diagrams/', 'ppt/fonts/', 'ppt/tags/',
)


def xml(z, name):
    return ET.fromstring(z.read(name))


def relations(z, owner):
    relpart = posixpath.join(posixpath.dirname(owner), '_rels',
                            posixpath.basename(owner) + '.rels')
    if relpart not in z.namelist():
        return {}
    result = {}
    for r in xml(z, relpart):
        if r.get('TargetMode') == 'External':
            continue
        target = unquote(r.get('Target', ''))
        resolved = posixpath.normpath(
            target.lstrip('/') if target.startswith('/')
            else posixpath.join(posixpath.dirname(owner), target))
        if resolved.startswith('../'):
            raise ValueError('Invalid package relationship target')
        result[r.get('Id')] = (r.get('Type', ''), resolved)
    return result


def note_text(z, part):
    paragraphs = []
    for sp in xml(z, part).findall('.//p:sp', NS):
        ph = sp.find('p:nvSpPr/p:nvPr/p:ph', NS)
        # Preserve structural chrome, but inspect body AND extra textboxes.
        if ph is not None and ph.get('type') in {'dt', 'hdr', 'ftr', 'sldNum', 'sldImg'}:
            continue
        for p in sp.findall('p:txBody/a:p', NS):
            paragraphs.append(''.join(t.text or '' for t in p.findall('.//a:t', NS)))
    return '\n'.join(paragraphs).strip()


def label_snapshot(z):
    snapshot = {}
    for n in z.namelist():
        if n.endswith('/LabelInfo.xml'):
            snapshot[n] = hashlib.sha256(z.read(n)).hexdigest()
    if 'docProps/custom.xml' in z.namelist():
        props = {}
        for prop in xml(z, 'docProps/custom.xml'):
            name = prop.get('name', '')
            if name.lower().startswith('msip_label_'):
                props[name] = ''.join(prop.itertext())
        if props:
            snapshot['MSIP_custom_properties'] = props
    return snapshot


def visual_snapshot(z):
    result = {}
    # Notes masters can own a separate theme. Their removal/resave is not a
    # slide-visual change; include only themes referenced outside notes parts.
    used_themes = set()
    for relpart in z.namelist():
        if not relpart.endswith('.rels') or '/_rels/' not in relpart:
            continue
        directory, filename = relpart.rsplit('/_rels/', 1)
        owner = posixpath.join(directory, filename[:-5])
        if owner.startswith(('ppt/notesSlides/', 'ppt/notesMasters/')):
            continue
        for typ, target in relations(z, owner).values():
            if typ.endswith(('/theme', '/themeOverride')):
                used_themes.add(target)
    for n in z.namelist():
        if n.endswith('/') or not (n.startswith(VISUAL_PREFIXES) or n == 'ppt/tableStyles.xml'):
            continue
        if n.startswith('ppt/theme/'):
            theme_owner = n
            if '/_rels/' in n and n.endswith('.rels'):
                directory, filename = n.rsplit('/_rels/', 1)
                theme_owner = posixpath.join(directory, filename[:-5])
            if theme_owner not in used_themes:
                continue
        data = z.read(n)
        if n.endswith('.rels'):
            # Customer copy may remove notes relationships; compare all others.
            rels = [dict(r.attrib) for r in ET.fromstring(data)
                    if not r.get('Type', '').endswith('/notesSlide')]
            if not rels:
                continue
            data = json.dumps(sorted(rels, key=lambda r: r.get('Id', '')),
                              ensure_ascii=False, sort_keys=True).encode('utf-8')
        result[n] = hashlib.sha256(data).hexdigest()
    return result


def inspect(path, mode):
    errors = []
    with zipfile.ZipFile(path) as z:
        bad = z.testzip()
        if bad:
            raise ValueError('ZIP CRC check failed')
        presentation = xml(z, 'ppt/presentation.xml')
        rels = relations(z, 'ppt/presentation.xml')
        refs = presentation.findall('p:sldIdLst/p:sldId', NS)
        if not refs:
            raise ValueError('Presentation has no slide IDs')
        all_notes = {n: note_text(z, n) for n in z.namelist() if NOTES_RE.match(n)}
        rows, order, linked = [], [], set()
        for page, ref in enumerate(refs, 1):
            rid = ref.get('{' + NS['r'] + '}id')
            relation = rels.get(rid)
            if relation is None or not relation[0].endswith('/slide'):
                raise ValueError('Missing or invalid slide relationship')
            part = relation[1]
            slide = xml(z, part)
            order.append(part)
            targets = [p for typ, p in relations(z, part).values() if typ.endswith('/notesSlide')]
            if len(targets) > 1:
                errors.append(f'Page {page}: multiple notes relationships')
            for target in targets:
                if target not in all_notes:
                    raise ValueError('Missing notes relationship target')
            linked.update(targets)
            text = '\n'.join(all_notes[t] for t in targets)
            headings = re.findall(r'【[^】]+】', text)
            if mode == 'presenter':
                if len(headings) != 2 or set(headings) != HEADINGS:
                    errors.append(f'Page {page}: expected only the two presenter fields')
                else:
                    for match in re.finditer(r'(【[^】]+】)(.*?)(?=【[^】]+】|\Z)', text, re.S):
                        if not match.group(2).strip():
                            errors.append(f'Page {page}: empty presenter field')
            rows.append({'page': page, 'slidePart': part,
                         'hidden': slide.get('show', '1') in {'0', 'false'},
                         'noteCharacters': len(text.strip()), 'noteHeadings': headings})
        nonempty = [n for n, t in all_notes.items() if t]
        if mode == 'customer' and nonempty:
            errors.append('Customer package contains nonempty notes text, including any orphan parts')
        size = presentation.find('p:sldSz', NS)
        summary = {
            'slideCount': len(rows), 'slides': rows,
            'notesPartCount': len(all_notes), 'nonemptyNotesPartCount': len(nonempty),
            'orphanNonemptyNotesPartCount': sum(bool(t) for n, t in all_notes.items() if n not in linked),
            'slideSizeEmu': dict(size.attrib) if size is not None else None,
            'slideOrder': order,
        }
        return summary, visual_snapshot(z), label_snapshot(z), errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('deck', type=Path)
    parser.add_argument('--mode', choices=['inspect', 'customer', 'presenter'], default='inspect')
    parser.add_argument('--baseline', type=Path)
    parser.add_argument('--require-visual-match', action='store_true')
    parser.add_argument('--require-same-label', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if (args.require_visual_match or args.require_same_label) and not args.baseline:
        parser.error('Comparison requirements need --baseline')
    if args.report and args.report.exists():
        parser.error('Report exists; choose a new output path')
    try:
        summary, visuals, labels, errors = inspect(args.deck, args.mode)
        result = {'mode': args.mode, 'deck': str(args.deck.resolve()), **summary,
                  'limitations': 'Read-only package checks, not rendering, complete OPC equivalence, secret detection, or native application verification.'}
        if args.baseline:
            base, basevisuals, baselabels, _ = inspect(args.baseline, 'inspect')
            different = sorted(n for n in set(visuals) | set(basevisuals)
                               if visuals.get(n) != basevisuals.get(n))
            sequence_same = summary['slideOrder'] == base['slideOrder']
            dimensions_same = summary['slideSizeEmu'] == base['slideSizeEmu']
            visual_match = not different and sequence_same and dimensions_same
            label_match = labels == baselabels
            result['comparison'] = {
                'baseline': str(args.baseline.resolve()),
                'selectedVisualPartsIdentical': visual_match,
                'differentSelectedVisualParts': different,
                'slideOrderIdentical': sequence_same, 'slideSizeIdentical': dimensions_same,
                'selectedLabelMetadataIdentical': label_match,
            }
            if args.require_visual_match and not visual_match:
                errors.append('Selected visual package parts, slide order or size changed')
            if args.require_same_label and not label_match:
                errors.append('Selected label metadata changed')
        result['errors'] = errors
        result['passed'] = not errors
        data = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
        if args.report:
            with args.report.open('x', encoding='utf-8') as f:
                f.write(data)
        print(data, end='')
        return 1 if errors else 0
    except (OSError, ValueError, KeyError, ET.ParseError, zipfile.BadZipFile) as exc:
        print(json.dumps({'passed': False, 'error': str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
