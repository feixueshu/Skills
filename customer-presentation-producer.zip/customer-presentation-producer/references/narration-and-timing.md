# Narration, timing, and demo alignment

## Japanese presenter-note profile

```text
【説明時間の目安】0分45秒

【読み上げ】
この画面では、設定の流れと確認する箇所をご説明します。
最初に対象を選び、変更内容を確認してから次の操作に進みます。
```

The example demonstrates the two fields, not text to repeat on every page. Keep useful rationale, exact objects, expected results, boundaries, and transitions. Private production cues, reference lists, and full running orders stay in private working records or appropriate slides, not additional note headings. A pre-demo introduction and post-demo conclusion can remain separate paragraphs inside the same spoken-text field; removing extra headings must not delete the conclusion.

Preserve actual UI labels while keeping a separate spoken form for acronyms, English words, numbers, and units. Generate a full voice track only if requested.

## Budget

`slide explanation + measured video + switching/playback overhead + reserve = event budget`

Allocate time by complexity, not one minute per slide. If too long, remove repetition or move details to an appendix before forcing unnatural speech or shortening readable holds. Mark character-count estimates and TTS timing as proxies. A real presenter rehearsal is the best check. Do not double-count the entire video as a slide's spoken narration.

Keep a private mapping: slide/step → application action → demo scene → expected evidence. Distinguish operations shown in the video, separate user-reported tests, planned validation, and unverified items. Updated notes may require a script or voice correction, not necessarily a new recording.

## Independent scripts

Only export when needed for rehearsal or requested. Extract from current note bodies. Track the source version/hash privately. A user's later PowerPoint edit invalidates an older export as authority. Do not include private scripts in a customer ZIP by default.
