# Fidelity and edition checks

## Baseline inventory

Inspect slide dimensions/order, masters/layouts, direct and theme colors, fonts, cover assets, footer, links, native objects, hidden slides, notes, labels, and audience restrictions. Record what may change. A new topic inherits the design system, not the old business content. A small revision preserves the rest.

## Four demonstrated failure modes

1. **Logo looks correct in a renderer but changes color in PowerPoint.** An SVG can depend on layout/theme color mappings such as `p:clrMapOvr` / `a:overrideClrMapping`. Compare the actual source and target asset relationships and color mapping. Do not redraw the logo or change the global theme to conceal a local mapping problem. Do not hard-code one historical `slideLayout1.xml` into all decks.
2. **A notes-only edit damages branding or labels.** A full re-export may change unrelated parts. Prefer a supported minimal edit, on a copy, with delta checks. Do not strip classification metadata or bypass protection. Binary equality of unchanged parts is useful evidence, not proof of native rendering.
3. **The customer edition still contains narration.** Follow actual slide relationships to note bodies; note file numbering need not match slide numbering. Inspect all note bodies, including unreferenced parts. Check comments, hidden content, embedded files, metadata, and the delivery ZIP. Preserve required copyright and structural relationships.
4. **An editable-looking deck is flattened.** Inspect the actual exported objects. UI screenshots can be raster images; ordinary text/tables/connectors should remain editable when the output supports it. Test real reference links and their intended recipients' access.

## Two-edition procedure

Freeze the authoritative visuals and latest notes. Produce only the requested editions. When notes are the only intended difference, require matching customer-facing visuals; record any intentional exception. Remove private notes from the customer edition and verify absence in the package. Render both and inspect the actual application when possible.

`audit_pptx.py --require-visual-match` covers selected shared visual package parts, slide order, and size—not every OPC relationship or rendering behavior. `--require-same-label` explicitly makes detected label differences blocking; do not restore an old label against an authorized new classification. The audit is read-only and is not an organizational classification or data-loss-prevention tool.
